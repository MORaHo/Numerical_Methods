from src.Maths import abs,acos,acosh,asin,asinh,atan,atanh,ceil,cos,cosh,ew,exp,floor,log,root,sin,sinh,sqrt,tan,tanh

abs = abs.abs
acos = acos.acos
acosh = acosh.acosh
asin = asin.asin
asinh = asinh.asinh
atan = atan.atan
atanh = atanh.atanh
ceil = ceil.ceil
cos = cos.cos
cosh = cosh.cosh
ew = ew.ew
exp = exp.exp
floor= floor.floor
log = log.log
root= root.root
sin = sin.sin
sinh = sinh.sinh
sqrt = sqrt.sqrt
tan = tan.tan
tanh = tanh.tanh