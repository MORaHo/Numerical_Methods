from src.LinAlg.matrix import ndarray,Matrix,Vector

def svd(A:Matrix) -> list[Matrix,Matrix,Matrix]:

    u = 0
    sigma = 0
    v = 0


    return [u,sigma,v]