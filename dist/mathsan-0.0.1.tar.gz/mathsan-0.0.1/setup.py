import setuptools
setuptools.setup()