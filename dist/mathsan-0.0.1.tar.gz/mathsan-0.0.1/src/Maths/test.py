from src.LinAlg.matrix import Matrix

def main():
    print(Matrix([[1,2,3],[4,5,6]]))

if __name__ == "__main__":
    main()